﻿@echo off
title Mobile Service Master - Local Server
echo Starting Local Server (Please wait)...
start /B python web_app.py
timeout /t 3 /nobreak > NUL
echo Opening Admin & Client Dashboards...
start http://127.0.0.1:5000/?role=admin
start http://127.0.0.1:5000/?role=client
echo =====================================
echo SERVER IS RUNNING. DO NOT CLOSE THIS WINDOW.
echo =====================================
pause
